import React, { useState } from 'react'
import Lobby from './components/Lobby'
import Arena from './components/Arena'

export default function App(){
  const [room, setRoom] = useState(null)
  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-4xl">
        <header className="mb-6">
          <h1 className="text-3xl font-bold text-yellow-400">🦍 Golden Ape Arena</h1>
          <p className="text-sm text-slate-300">Player vs Player NFT card battles • Reward: Base (ETH on Base L2)</p>
        </header>
        {!room ? <Lobby onCreate={setRoom} onJoin={setRoom}/> : <Arena room={room} onExit={()=>setRoom(null)}/>}        
        <footer className="mt-6 text-xs text-slate-500">Note: this demo uses a centralized resolver (owner) to pay out winners. For trustless game, use on-chain RNG/commit-reveal or an oracle.</footer>
      </div>
    </div>
  )
}
