import React, { useState } from 'react'
import { v4 as uuidv4 } from 'uuid'

export default function Lobby({ onCreate, onJoin }){
  const [roomId, setRoomId] = useState('')
  const [wager, setWager] = useState('0.01')

  function createRoom(){
    const id = uuidv4().split('-')[0]
    onCreate({ id, wager })
  }

  function joinRoom(){
    if(!roomId) return alert('Enter room id')
    onJoin({ id: roomId, wager })
  }

  return (
    <div className="bg-slate-900 p-6 rounded-xl shadow">
      <h2 className="text-xl font-bold mb-2">Create / Join Battle Room</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 items-end">
        <div>
          <label className="text-xs text-slate-400">Wager (ETH on Base)</label>
          <input className="mt-1 p-2 bg-slate-800 rounded w-full" value={wager} onChange={(e)=>setWager(e.target.value)}/>
        </div>
        <div>
          <label className="text-xs text-slate-400">Room ID (join)</label>
          <input className="mt-1 p-2 bg-slate-800 rounded w-full" value={roomId} onChange={(e)=>setRoomId(e.target.value)}/>
        </div>
        <div className="flex gap-2">
          <button onClick={createRoom} className="px-4 py-2 bg-yellow-500 rounded font-bold">Create Room</button>
          <button onClick={joinRoom} className="px-4 py-2 bg-slate-700 rounded">Join Room</button>
        </div>
      </div>
      <p className="mt-4 text-sm text-slate-400">After creating a room, share Room ID with an opponent. Both players will deposit the wager to the Escrow contract and select an NFT to battle.</p>
    </div>
  )
}
