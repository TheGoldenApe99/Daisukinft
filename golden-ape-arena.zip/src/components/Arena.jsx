import React, { useEffect, useState } from 'react'
import { ethers } from 'ethers'

const ESCROW_ADDRESS = '0xREPLACE_ESCROW_CONTRACT_ADDRESS'
const NFT_CONTRACT = '0x5676fCF549f434D0D1E71baD9370cdb451968109'

export default function Arena({ room, onExit }){
  const [status,setStatus] = useState('Waiting for players')
  const [account,setAccount] = useState(null)
  const [opponent,setOpponent] = useState('')
  const [myTokenId,setMyTokenId] = useState('')
  const [oppTokenId,setOppTokenId] = useState('')
  const [result,setResult] = useState(null)
  const [provider,setProvider] = useState(null)

  useEffect(()=>{
    if(window.ethereum){
      const p = new ethers.BrowserProvider(window.ethereum)
      setProvider(p)
      p.send('eth_requestAccounts', []).then(()=>p.getSigner().getAddress().then(a=>setAccount(a))).catch(()=>{})
    }
    setStatus('Room: ' + room.id + ' • Wager: ' + room.wager + ' ETH')
  },[room])

  async function depositToEscrow(){
    if(!provider) return setStatus('Connect wallet first')
    try{
      const signer = await provider.getSigner()
      const escrow = new ethers.Contract(ESCROW_ADDRESS, ['function deposit(bytes32 roomId) payable','function declareWinner(bytes32 roomId,address winner)'], signer)
      const value = ethers.parseEther(String(room.wager))
      const roomKey = ethers.keccak256(ethers.toUtf8Bytes(room.id))
      const tx = await escrow.deposit(roomKey, { value })
      setStatus('Deposit tx sent: ' + tx.hash)
      await tx.wait()
      setStatus('Deposit confirmed. Waiting for opponent.')
    }catch(e){ console.error(e); setStatus('Deposit failed: ' + (e.message||e)) }
  }

  function simpleResolve(aToken,bToken){
    const score = (id)=>{ let s=0; for(let c of String(id)) s+=c.charCodeAt(0); return s % 100 }
    const sa = score(aToken); const sb = score(bToken)
    if(sa===sb) return Math.random()>0.5? 'a':'b'
    return sa>sb? 'a':'b'
  }

  async function resolveBattle(){
    if(!myTokenId || !oppTokenId) return setStatus('Set both token IDs')
    setStatus('Resolving battle...')
    const winner = simpleResolve(myTokenId, oppTokenId) === 'a' ? account : opponent
    setResult({ winner })
    setStatus('Winner: ' + winner)
    setStatus('To payout, contract owner must call declareWinner with the room id and winner address (owner-resolve).')
  }

  return (
    <div className="bg-slate-900 p-6 rounded-xl shadow">
      <div className="flex justify-between items-center mb-4">
        <div>
          <div className="text-sm text-slate-400">Room ID</div>
          <div className="font-mono">{room.id}</div>
        </div>
        <div className="text-sm text-slate-400">Wager: {room.wager} ETH</div>
        <div><button className="px-3 py-1 bg-slate-700 rounded" onClick={onExit}>Exit</button></div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="p-4 bg-slate-800 rounded">
          <h3 className="font-bold">You</h3>
          <div className="text-xs text-slate-400">Address</div>
          <div className="font-mono text-sm">{account||'not connected'}</div>
          <div className="mt-2">
            <label className="text-xs text-slate-400">Your NFT Token ID</label>
            <input className="mt-1 p-2 bg-slate-700 rounded w-full" value={myTokenId} onChange={e=>setMyTokenId(e.target.value)}/>
          </div>
          <div className="mt-3">
            <button onClick={depositToEscrow} className="bg-yellow-500 px-3 py-2 rounded font-bold">Deposit Wager</button>
          </div>
        </div>

        <div className="p-4 bg-slate-800 rounded">
          <h3 className="font-bold">Opponent</h3>
          <div className="text-xs text-slate-400">Enter opponent address</div>
          <input className="mt-1 p-2 bg-slate-700 rounded w-full" value={opponent||''} onChange={e=>setOpponent(e.target.value)}/>
          <div className="mt-2">
            <label className="text-xs text-slate-400">Opponent Token ID</label>
            <input className="mt-1 p-2 bg-slate-700 rounded w-full" value={oppTokenId} onChange={e=>setOppTokenId(e.target.value)}/>
          </div>
        </div>
      </div>

      <div className="mt-4 flex gap-3">
        <button onClick={resolveBattle} className="bg-amber-600 px-4 py-2 rounded">Resolve Battle</button>
        <button className="bg-slate-700 px-3 py-2 rounded" onClick={()=>setStatus('Battle preview run')}>Preview</button>
      </div>

      <div className="mt-4 text-sm text-slate-300">Status: {status}</div>
      {result && <div className="mt-3 text-green-400">Winner: {result.winner}</div>}
      <div className="mt-4 text-xs text-slate-500">Note: This demo resolves battles off-chain deterministically and requires the Escrow contract owner to call declareWinner(roomId,winner) to payout the winner on-chain.</div>
    </div>
  )
}
