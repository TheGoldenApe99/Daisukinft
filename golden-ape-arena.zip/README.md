Golden Ape Arena - PvP NFT Card Battle Mini App

Overview:
- PvP mini-app where two players deposit equal ETH wagers (on Base) into an Escrow contract and select one NFT each to battle.
- Battle is resolved off-chain deterministically (demo uses simple tokenId-based function). The contract owner must call declareWinner(roomId,winner) to pay out.

Files:
- src/ : React + Tailwind mini-app
- contracts/PvPEscrow.sol : simple escrow contract

How it works:
1. Deploy PvPEscrow on Base mainnet (or testnet) and set ESCROW_ADDRESS in src/components/Arena.jsx
2. Player A creates room and deposits wager by clicking Deposit Wager (calls escrow.deposit)
3. Player B joins, deposits same wager
4. Both players input token IDs to battle and click Resolve Battle. The frontend computes winner deterministically.
5. The owner (you or a trusted resolver) calls declareWinner(roomId, winner) on the Escrow contract to transfer the pooled ETH to the winner.

Security & Trust:
- This demo uses centralized resolution (owner must declare winner). For a production trustless system implement commit-reveal or on-chain verification.
- Always audit contracts before mainnet use.

Deploy steps:
- Frontend: npm install && npm run build -> deploy dist/ to Vercel or Netlify
- Contract: compile & deploy using Remix or Hardhat
